FinatriX sample statement files (all fictional)

Use them in the app: Expenses > Import > choose a file.

sample-statement.csv        A bank statement as CSV. Reads as 7 transactions; review them, then confirm.
sample-statement.pdf        The same idea as a PDF. Reads as 5 transactions. PDF import needs iOS 18 or later.
sample-statement-photo.png  A statement photo. Open it full screen on another screen, then Expenses > Import > Take Photo
                            and photograph it; 5 rows are read on the device and offered for review.

Nothing here is real account data, and the photo never leaves the device.
No account is needed to try any of this.
